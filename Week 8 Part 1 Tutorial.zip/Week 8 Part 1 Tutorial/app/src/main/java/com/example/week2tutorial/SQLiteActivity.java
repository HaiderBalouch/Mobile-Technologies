package com.example.week2tutorial;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class SQLiteActivity extends AppCompatActivity {
    Spinner spinner;
    ArrayList<String> items = new ArrayList<>();
    ArrayAdapter<String> adapter;
    MyDbHelper dbHelper;
    String selectedItem = "";
    EditText editTextName, editTextMark, editTextNewMark;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sqlite);

        dbHelper = new MyDbHelper(SQLiteActivity.this, "MobileTechResults", null, 1);

        spinner = findViewById(R.id.spinner);
        editTextName = findViewById(R.id.editTextName);
        editTextMark = findViewById(R.id.editTextMark);
        editTextNewMark = findViewById(R.id.editTextNewMark);

        refreshSpinner();

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedItem = parent.getItemAtPosition(position).toString();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void refreshSpinner() {
        items = dbHelper.readAll();
        items.add(0, "Select an item");
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }

    public void save(View view) {
        String name = editTextName.getText().toString();
        String mark = editTextMark.getText().toString();
        if (!name.isEmpty() && !mark.isEmpty()) {
            if (dbHelper.create(name, mark) != -1) {
                Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
                refreshSpinner();
            } else {
                Toast.makeText(this, "Error saving data", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Please enter name and mark", Toast.LENGTH_SHORT).show();
        }
    }

    public void update(View view) {
        if (spinner.getSelectedItem() != null && spinner.getSelectedItemPosition() != 0) {
            String selected = spinner.getSelectedItem().toString();
            String name = selected.split(",")[0].replace("Name: ", "").trim();
            String newMark = editTextNewMark.getText().toString();
            if (!newMark.isEmpty()) {
                dbHelper.update(name, newMark);
                Toast.makeText(this, "Updated", Toast.LENGTH_SHORT).show();
                refreshSpinner();
            } else {
                Toast.makeText(this, "Please enter new mark", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Please select an item to update", Toast.LENGTH_SHORT).show();
        }
    }

    public void delete(View view) {
        if (spinner.getSelectedItem() != null && spinner.getSelectedItemPosition() != 0) {
            String selected = spinner.getSelectedItem().toString();
            String name = selected.split(",")[0].replace("Name: ", "").trim();
            dbHelper.delete(name);
            Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
            refreshSpinner();
        } else {
            Toast.makeText(this, "Please select an item to delete", Toast.LENGTH_SHORT).show();
        }
    }
}
